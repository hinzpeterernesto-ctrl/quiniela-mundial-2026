# ⚽ Quiniela Mundial 2026

Aplicación PWA para jugar la quiniela del Mundial 2026 con tus amigos.

## 🚀 Cómo publicarla GRATIS en Vercel (paso a paso)

### Paso 1: Crear cuenta en GitHub
1. Ve a https://github.com y crea una cuenta gratuita (si no tienes)
2. Haz clic en **"New repository"** (botón verde)
3. Ponle nombre: `quiniela-mundial-2026`
4. Déjalo **público**
5. Clic en **"Create repository"**

### Paso 2: Subir los archivos
**Opción A — Desde la web de GitHub (más fácil):**
1. En tu repo nuevo, haz clic en **"uploading an existing file"**
2. Arrastra TODA la carpeta `quiniela-mundial` descomprimida
3. Clic en **"Commit changes"**

**Opción B — Desde la terminal (si tienes Git instalado):**
```bash
cd quiniela-mundial
git init
git add .
git commit -m "Quiniela Mundial 2026"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/quiniela-mundial-2026.git
git push -u origin main
```

### Paso 3: Publicar en Vercel
1. Ve a https://vercel.com y regístrate con tu cuenta de GitHub
2. Haz clic en **"Add New" → "Project"**
3. Importa tu repositorio `quiniela-mundial-2026`
4. Vercel detectará automáticamente que es un proyecto React
5. Haz clic en **"Deploy"**
6. ¡Listo! En ~2 minutos tendrás tu URL tipo: `quiniela-mundial-2026.vercel.app`

### Paso 4: Instalar como App en el celular
1. Abre la URL en el navegador del celular
2. **iPhone:** Toca el botón de compartir (↑) → "Agregar a pantalla de inicio"
3. **Android:** Toca los 3 puntos (⋮) → "Agregar a pantalla de inicio"
4. ¡Se instala como app con ícono y todo!

## 📱 Cómo jugar
1. Comparte el link con tus amigos
2. Cada quien agrega su nombre en **Inicio**
3. Selecciona tu nombre y ve a **Jugar** para poner tus pronósticos
4. Cuando se jueguen los partidos, alguien mete los resultados en **Resultados**
5. La **Tabla** se actualiza automática

## 🏆 Sistema de puntaje
- **+5 pts** — Marcador exacto
- **+3 pts** — Aciertas quién gana o empate
- **+1 pt** — Aciertas goles de un equipo
- **0 pts** — Sin acierto

## ⚠️ Nota importante
Los datos se guardan en el **localStorage del navegador** de cada dispositivo. Esto significa que:
- Cada celular tiene sus propios datos
- Si alguien borra los datos del navegador, pierde sus pronósticos
- Lo ideal es que **UNA persona** sea el admin que mete los resultados reales

Si quieres que todos compartan los mismos datos, necesitarías agregar una base de datos (como Firebase). ¡Pídemelo y te ayudo!
